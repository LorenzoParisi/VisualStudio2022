﻿namespace MaxMinNInteri
{
    internal class Program
    //   Mobile App Developer, Fondamenti di programmazione, Parisi, Lorenzo, 15 aprile 2024
    {
        static void Main(string[] args)
        {
            /*dati in input N numeri interi, determinare il max dei soli positivi e il min dei soli negativi inseriti e visualizzare i risultati
            */
            /*input
             */
            Console.Write("Inserire il numero di valori:");
            int n= int.Parse(Console.ReadLine());

        }
    }
}
